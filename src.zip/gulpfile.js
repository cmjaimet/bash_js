const gulp = require( 'gulp' );
// Gulp dependencies go here

gulp.task( 'default', function() {
  // Gulp tasks go here
})
